# Design System Specification: The Clinical Architect

## 1. Overview & Creative North Star

### Creative North Star: "The Clinical Architect"
In the high-stakes environment of medical diagnostics, clarity is not just an aesthetic—it is a functional requirement. This design system moves away from the sterile, "boxy" templates of legacy medical software. Instead, it adopts the persona of **The Clinical Architect**: a sophisticated, editorial-inspired framework that treats medical data with the same intentionality as a high-end architectural blueprint.

We break the "standard dashboard" mold through **intentional asymmetry**, **tonal layering**, and **monumental typography**. By replacing rigid 1px borders with subtle shifts in surface luminosity, we create a workspace that feels expansive, breathable, and authoritative. This is a premium workbench designed for clinicians who require high-density data without the cognitive load of a cluttered interface.

---

## 2. Colors & Surface Logic

Our palette is anchored in medical trust but elevated through sophisticated tonal ranges. We utilize a high-contrast relationship between deep action blues and soft, layered neutrals to guide the eye toward critical diagnostic pathways.

### The "No-Line" Rule
**Designers are strictly prohibited from using 1px solid borders for sectioning.** 
Structural boundaries must be defined exclusively through background color shifts. For example, a `surface-container-low` (#f2f4f7) navigation panel should sit adjacent to a `surface` (#f7f9fc) workspace. Use the natural contrast between tokens to define where one functional zone ends and another begins.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of premium materials. Use the `surface-container` tiers to create depth:
- **Canvas (`surface` #f7f9fc):** The base layer of the application.
- **Structural Zones (`surface-container-low` #f2f4f7):** Used for sidebars and utility panels.
- **Active Workspaces (`surface-container-lowest` #ffffff):** Use the brightest white for the primary data entry and viewing cards to "lift" them toward the user.
- **Nested Detail (`surface-container-high` #e6e8eb):** Use for internal grouping within a card to denote secondary information.

### The Glass & Gradient Rule
To prevent the UI from feeling "flat," main Call-to-Actions (CTAs) and primary status indicators should utilize a **Signature Texture**: a subtle linear gradient transitioning from `primary` (#005daa) to `primary_container` (#0075d5). For floating overlays or modal headers, apply **Glassmorphism**: use a semi-transparent `surface` color with a `backdrop-blur` (12px–20px) to allow the underlying data to bleed through softly, maintaining context.

---

## 3. Typography: The Editorial Data Scale

We use typography as a structural element. By pairing the technical precision of **Mona Sans VF** with the functional clarity of **Inter**, we create an editorial hierarchy that makes complex medical results immediately scannable.

- **Display & Headline (Mona Sans VF):** Used for patient names and primary diagnostic categories. Use a bold weight (75%) to anchor the page. The high x-height and wide apertures of Mona Sans provide an authoritative, "Journal-grade" feel.
- **Title & Body (Inter):** The workhorse for medical notes and lab values. Inter’s neutrality ensures that even high-density data tables remain legible during long shifts.
- **Data Mono (ui-monospace):** Strictly reserved for Lab IDs, timestamps, and genomic sequences. This weight (25%) provides a "technological" contrast to the organic body text.

**Hierarchy Tip:** Use `headline-lg` (2rem) for the primary patient context and `label-sm` (0.6875rem) in all-caps with 0.05em tracking for metadata headers to create a sophisticated, "spec-sheet" look.

---

## 4. Elevation & Depth: Tonal Layering

Traditional drop shadows are often messy in high-density medical apps. This design system relies on **Tonal Layering** to convey importance.

### The Layering Principle
Depth is achieved by "stacking" luminosity. A `surface-container-lowest` card placed on a `surface-container-low` background creates a natural, soft lift. This mimics the appearance of fine paper resting on a desk, requiring no artificial shadows to be understood as a separate layer.

### Ambient Shadows
Where floating elements (like tooltips or dropdowns) are required, use **Ambient Shadows**:
- **Color:** A tinted version of `on-surface` (#191c1e) at 4–8% opacity.
- **Blur:** Large, diffused values (e.g., `box-shadow: 0 12px 32px rgba(25, 28, 30, 0.08)`).
- **Purpose:** To mimic natural light, not to create a hard edge.

### The "Ghost Border" Fallback
If a boundary is required for accessibility (e.g., in a high-glare environment), use a **Ghost Border**. Apply `outline-variant` (#c0c7d6) at 20% opacity. This provides a "suggestion" of a line without breaking the "No-Line" rule's fluid aesthetic.

---

## 5. Components

### Buttons
- **Primary:** Gradient from `primary` to `primary_container`. Roundedness: `md` (0.375rem). No border.
- **Secondary:** Surface-tinted. Use `surface-container-highest` background with `primary` text.
- **States:** On hover, increase the gradient intensity. On press, use a subtle inner shadow to simulate physical depression.

### Cards & Lists
**Strict Rule:** No dividers (`<hr>`). 
Separate list items using `body-md` padding (16px) and subtle alternating background shifts (Zebra striping) using `surface` and `surface-container-low`. For cards, use `xl` (0.75rem) corner radius for a modern, approachable feel.

### Input Fields
- **Default State:** A `surface-container-highest` background with a `Ghost Border`.
- **Focus State:** The background shifts to `surface-container-lowest` (white), and the border becomes a solid 2px `primary` glow.
- **Clinical Efficiency:** Use `ui-monospace` for numerical inputs to ensure digit alignment.

### Chips (Health Status)
Chips should be semi-transparent to feel integrated:
- **Success:** Background `success_green` (at 15% opacity), text `success_green` (at 100%).
- **Danger:** Background `error_container` (#ffdad6), text `on_error_container` (#93000a).

### The Diagnostic Strip (Custom Component)
A horizontal high-density bar at the top of the workbench. Use `surface-dim` (#d8dadd) for the background and `surface-container-lowest` for nested "data-bits" (small modules containing vital signs). This creates a "dashboard within a dashboard" effect using only tonal shifts.

---

## 6. Do's and Don'ts

### Do
- **DO** use white space as a structural tool. A 32px gap is more effective than a gray line.
- **DO** use `surface-bright` for highlights in data visualization to make specific metrics "glow."
- **DO** align all text to a strict 4px baseline grid to maintain editorial precision.
- **DO** use iconography from a single, consistent line-art set with a 1.5pt stroke weight.

### Don'ts
- **DON'T** use 100% black (#000000) for text. Use `on-surface` (#191c1e) to reduce eye strain.
- **DON'T** use sharp 0px corners. Every element must have at least `sm` (0.125rem) roundedness to feel "medical-grade" and safe.
- **DON'T** use high-saturation reds for anything other than critical medical errors. Use `tertiary` (#545d66) for neutral "empty" states.
- **DON'T** clutter the workspace. If a piece of data isn't critical to the current clinical task, hide it within a `surface-container-high` progressive disclosure panel.